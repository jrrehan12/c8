import turtle

def draw_star():
    turtle.penup()
    turtle.goto(x,y)
    turtle.pendown()
    for i in range():
        turtle.fd()
        turtle.right()

draw_star(10,30,10)
draw_star(30,60,20)
